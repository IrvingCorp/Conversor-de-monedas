/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.service;

/**
 *
 * @author Eduardo Reyes Hernández
 */
public interface IKeys {

    public static final String KEY_ONE = "ODc2ODk4Mjk4OTBERkdHOQ==";
    public static final String KEY_TWO = "OE5KTjg3NzcyWUhIU0oxOQ==";
}
